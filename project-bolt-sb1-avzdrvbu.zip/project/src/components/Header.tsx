import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import LanguageSwitcher from './common/LanguageSwitcher';

interface HeaderProps {
  language: string;
  onLanguageChange: (language: string) => void;
}

export default function Header({ language, onLanguageChange }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  const navItems = {
    en: ['Home', 'Services', 'AI Solutions', 'Portfolio', 'Clients', 'About', 'Contact'],
    ar: ['الرئيسية', 'الخدمات', 'حلول الذكاء الاصطناعي', 'المعرض', 'العملاء', 'من نحن', 'اتصل بنا']
  };

  const navLinks = {
    en: ['home', 'services', 'ai', 'portfolio', 'clients', 'about', 'contact'],
    ar: ['home', 'services', 'ai', 'portfolio', 'clients', 'about', 'contact']
  };

  const currentNavItems = navItems[language as keyof typeof navItems] || navItems.en;
  const currentNavLinks = navLinks[language as keyof typeof navLinks] || navLinks.en;

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${language === 'ar' ? 'rtl' : 'ltr'} ${
      scrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex-shrink-0 cursor-pointer" onClick={() => scrollToSection('hero')}>
            {scrolled ? (
              <img 
                src="/Twinhub Logo_Artboard 14-2_Artboard 14.png" 
                alt="Twinhub Logo" 
                className="h-12 w-auto hover:scale-105 transition-transform duration-300"
              />
            ) : (
              <img 
                src="/Twinhub Logo_Artboard 14.png" 
                alt="Twinhub Logo" 
                className="h-12 w-auto hover:scale-105 transition-transform duration-300"
              />
            )}
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {currentNavItems.map((item, index) => (
              <button
                key={item}
                onClick={() => scrollToSection(currentNavLinks[index])}
                className={`font-medium transition-colors duration-300 hover:text-red-600 ${
                  scrolled ? 'text-gray-800' : 'text-white'
                }`}
              >
                {item}
              </button>
            ))}
          </nav>

          {/* Language Switcher & Mobile Menu */}
          <div className="flex items-center space-x-4">
            <LanguageSwitcher 
              currentLanguage={language}
              onLanguageChange={onLanguageChange}
            />
            
          {/* Mobile Menu Button */}
            <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className={`p-2 rounded-md transition-colors duration-300 ${
                scrolled ? 'text-gray-800 hover:text-red-600' : 'text-white hover:text-red-300'
              }`}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-white/95 backdrop-blur-md shadow-lg">
            <div className="px-4 py-6 space-y-4">
              {currentNavItems.map((item, index) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(currentNavLinks[index])}
                  className="block w-full text-left font-medium text-gray-800 hover:text-red-600 transition-colors duration-300"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}