import { useState } from 'react';

const clientLogos = [
  {
    id: 1,
    name: 'TechCorp',
    logo: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=200&h=100',
    category: 'Technology'
  },
  {
    id: 2,
    name: 'Fashion Brand',
    logo: 'https://images.pexels.com/photos/3184328/pexels-photo-3184328.jpeg?auto=compress&cs=tinysrgb&w=200&h=100',
    category: 'Fashion'
  },
  {
    id: 3,
    name: 'Media Group',
    logo: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=200&h=100',
    category: 'Media'
  },
  {
    id: 4,
    name: 'Corporate Solutions',
    logo: 'https://images.pexels.com/photos/3184317/pexels-photo-3184317.jpeg?auto=compress&cs=tinysrgb&w=200&h=100',
    category: 'Corporate'
  },
  {
    id: 5,
    name: 'Entertainment Co',
    logo: 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg?auto=compress&cs=tinysrgb&w=200&h=100',
    category: 'Entertainment'
  },
  {
    id: 6,
    name: 'Luxury Brand',
    logo: 'https://images.pexels.com/photos/1024993/pexels-photo-1024993.jpeg?auto=compress&cs=tinysrgb&w=200&h=100',
    category: 'Luxury'
  }
];

interface ClientsSectionProps {
  language: string;
}

export default function ClientsSection({ language }: ClientsSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  
  const categories = ['All', 'Technology', 'Fashion', 'Media', 'Corporate', 'Entertainment', 'Luxury'];
  
  const filteredClients = selectedCategory === 'All' 
    ? clientLogos 
    : clientLogos.filter(client => client.category === selectedCategory);

  const content = {
    en: {
      title: 'Clients & Success Partners',
      subtitle: 'Trusted by leading brands across industries',
      description: 'We\'ve had the privilege of working with amazing clients who trust us to bring their visions to life.',
      stats: {
        projects: 'Projects Completed',
        clients: 'Happy Clients',
        experience: 'Years Experience',
        satisfaction: 'Client Satisfaction'
      }
    },
    ar: {
      title: 'العملاء وشركاء النجاح',
      subtitle: 'موثوق من قبل العلامات التجارية الرائدة عبر الصناعات',
      description: 'لقد حظينا بشرف العمل مع عملاء رائعين يثقون بنا لتحقيق رؤاهم.',
      stats: {
        projects: 'مشروع مكتمل',
        clients: 'عميل سعيد',
        experience: 'سنة خبرة',
        satisfaction: 'رضا العملاء'
      }
    }
  };

  const t = content[language as keyof typeof content] || content.en;

  return (
    <section id="clients" className="py-20 bg-gray-50 relative overflow-hidden">
      {/* Cinematic Background Elements */}
      <div className="absolute top-1/4 left-0 opacity-5 pointer-events-none decorative-pulse">
        <img 
          src="/Twinhub Logo_Artboard 17-3_Artboard 17_Artboard 17.png"
          alt="Decorative M"
          className="h-64 w-auto"
        />
      </div>
      
      {/* Film grain overlay */}
      <div className="absolute inset-0 opacity-5 bg-pattern"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            {t.title.split(' & ')[0]} <span className="text-red-600">& {t.title.split(' & ')[1]}</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed mb-8">
            {t.subtitle}
          </p>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {t.description}
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-red-600 text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-gray-100 hover:text-red-600'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Client Logos Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          {filteredClients.map((client, index) => (
            <div
              key={client.id}
              className="group bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 card-hover"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden mb-4 image-hover">
                <img
                  src={client.logo}
                  alt={client.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <h3 className="text-sm font-semibold text-gray-900 text-center group-hover:text-red-600 transition-colors duration-300">
                {client.name}
              </h3>
              <p className="text-xs text-gray-500 text-center mt-1">{client.category}</p>
            </div>
          ))}
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mt-20 pt-16 border-t border-gray-200">
          <div className="text-center">
            <div className="text-4xl font-bold text-red-600 mb-2">150+</div>
            <div className="text-gray-600 font-medium">
              {t.stats.projects}
            </div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-red-600 mb-2">60+</div>
            <div className="text-gray-600 font-medium">
              {t.stats.clients}
            </div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-red-600 mb-2">20+</div>
            <div className="text-gray-600 font-medium">
              {t.stats.experience}
            </div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-red-600 mb-2">99%</div>
            <div className="text-gray-600 font-medium">
              {t.stats.satisfaction}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}