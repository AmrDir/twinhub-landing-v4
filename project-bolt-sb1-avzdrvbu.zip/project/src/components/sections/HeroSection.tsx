import { useState, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';
import MediaBackground from '../common/MediaBackground';

interface HeroSectionProps {
  language: string;
}

export default function HeroSection({ language }: HeroSectionProps) {
  const [currentText, setCurrentText] = useState(0);
  
  const content = {
    en: {
      texts: ['Cinematic Stories', 'Brand Experiences', 'Creative Visions', 'Digital Content'],
      weCreate: 'We Create',
      subtitle: 'We keep pace with the latest developments in advertising and AI, offering creative design and implementation with speed, high quality, and competitive prices.',
      exploreWork: 'Explore Our Work',
      startProject: 'Start Your Project'
    },
    ar: {
      texts: ['قصص سينمائية', 'تجارب العلامة التجارية', 'رؤى إبداعية', 'محتوى رقمي'],
      weCreate: 'نحن نبدع',
      subtitle: 'نواكب أحدث التطورات في الإعلان والذكاء الاصطناعي، ونقدم التصميم الإبداعي والتنفيذ بسرعة وجودة عالية وأسعار تنافسية.',
      exploreWork: 'استكشف أعمالنا',
      startProject: 'ابدأ مشروعك'
    }
  };

  const t = content[language as keyof typeof content] || content.en;

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentText((prev) => (prev + 1) % t.texts.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [t.texts.length]);

  const scrollToServices = () => {
    const element = document.getElementById('services');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <MediaBackground
        backgroundImage="https://images.pexels.com/photos/3184296/pexels-photo-3184296.jpeg?auto=compress&cs=tinysrgb&w=1920"
        overlayOpacity={0.6}
        className="absolute inset-0"
      >
        {/* Cinematic Elements */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/3 right-1/4 w-80 h-80 bg-white/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
        
        {/* Film grain overlay */}
        <div className="absolute inset-0 opacity-20 bg-pattern"></div>
      </MediaBackground>

      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        {/* Main Logo */}
        <div className="mb-8 animate-fade-in-up">
          <img 
            src="/Twinhub Logo_Artboard 14.png"
            alt="Twinhub Creative Media Production" 
            className="mx-auto h-32 sm:h-40 lg:h-48 w-auto hover:scale-105 transition-transform duration-500 logo-float"
          />
        </div>

        {/* Decorative M Symbol */}
        <div className="absolute top-20 right-10 opacity-10 animate-pulse delay-1000">
          <img 
            src="/Twinhub Logo_Artboard 17-3_Artboard 17_Artboard 17.png"
            alt="Twinhub M Symbol"
            className="h-32 w-auto decorative-pulse"
          />
        </div>

        {/* Animated Text */}
        <div className="mb-8">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white mb-4 animate-fade-in-up delay-300">
            {t.weCreate}
          </h1>
          <div className="h-16 sm:h-20 flex items-center justify-center">
            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-bold text-red-500 animate-fade-in-up delay-500">
              {t.texts[currentText]}
            </h2>
          </div>
        </div>

        {/* Subtitle */}
        <p className="text-xl sm:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed animate-fade-in-up delay-700">
          {t.subtitle}
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-6 justify-center mb-16 animate-fade-in-up delay-1000">
          <button 
            onClick={scrollToServices}
            className="btn-primary"
          >
            {t.exploreWork}
          </button>
          <button 
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="btn-secondary"
          >
            {t.startProject}
          </button>
        </div>

        {/* Scroll Indicator */}
        <div className="animate-bounce">
          <button onClick={scrollToServices} className="text-white/70 hover:text-white transition-colors duration-300">
            <ChevronDown size={32} />
          </button>
        </div>
      </div>
    </section>
  );
}