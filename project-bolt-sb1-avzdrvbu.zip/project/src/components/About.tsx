import { Award, Users, Clock, Target, Brain, Globe, Camera, Palette } from 'lucide-react';

const stats = [
  { icon: Award, value: '150+', label: 'Projects Completed' },
  { icon: Users, value: '60+', label: 'Happy Clients' },
  { icon: Clock, value: '20+', label: 'Years Experience' },
  { icon: Target, value: '99%', label: 'Client Satisfaction' }
];

const services = [
  { name: 'Video Production for Business', icon: Camera },
  { name: 'Artificial Intelligence Center', icon: Brain },
  { name: 'TV Commercial Ads', icon: Globe },
  { name: 'Corporate Videos', icon: Camera },
  { name: 'Documentary Film', icon: Camera },
  { name: 'Animation Videos', icon: Palette },
  { name: 'Copyright & Music', icon: Award },
  { name: 'Fashion Design', icon: Palette },
  { name: 'Exhibition & Events', icon: Users },
  { name: 'Branding & Design', icon: Palette },
  { name: 'Photography Production', icon: Camera },
  { name: 'AI and Innovation Department', icon: Brain }
];

export default function About() {
  return (
    <section id="about" className="py-20 bg-white relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-1/4 right-0 opacity-5 pointer-events-none decorative-pulse">
        <img 
          src="/Twinhub Logo_Artboard 17-3_Artboard 17_Artboard 17.png"
          alt="Decorative M"
          className="h-96 w-auto"
        />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            About <span className="text-red-600">TwinHub</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            We keep pace with the latest developments in the world of advertising and artificial intelligence, 
            offering you creative design and implementation, with speed, high quality, and competitive prices.
          </p>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div 
              key={stat.label}
              className="text-center group"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="w-16 h-16 bg-red-600 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-red-700 transition-colors duration-300">
                <stat.icon className="w-8 h-8 text-white" />
              </div>
              <div className="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">{stat.value}</div>
              <div className="text-gray-600 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* About Us Section */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          <div className="relative">
            {/* Decorative HUB text */}
            <div className="absolute -top-8 -left-8 opacity-5 pointer-events-none">
              <img 
                src="/Twinhub Logo_Artboard 19.png"
                alt="Hub"
                className="h-24 w-auto"
              />
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">About TwinHub Agency</h3>
            <div className="space-y-6 text-gray-600 leading-relaxed">
              <p>
                At TwinHub Agency, we work together to provide you with superior advertising creativity 
                to communicate your services and products to your clients in the best possible way.
              </p>
              <p>
                We are based in Egypt, the most creative, diverse, and entertaining country in the region. 
                It's no surprise that we take as much pride in our work as we do in our origins.
              </p>
              <p>
                We're not just an agency, we're a trusted partner committed to delivering innovative 
                solutions that combine traditional creativity with cutting-edge artificial intelligence.
              </p>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/3184296/pexels-photo-3184296.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="TwinHub Creative Studio"
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-red-600 rounded-2xl flex items-center justify-center">
              <div className="text-white text-center">
                <div className="text-2xl font-bold">20+</div>
                <div className="text-sm">Years</div>
              </div>
            </div>
          </div>
        </div>

        {/* Vision & Mission */}
        <div className="grid md:grid-cols-2 gap-12 mb-20">
          <div className="bg-gray-50 p-8 rounded-2xl">
            <h3 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
              <Target className="w-8 h-8 text-red-600 mr-3" />
              Our Vision
            </h3>
            <p className="text-gray-600 leading-relaxed">
              We offer integrated media production, smart, results-oriented solutions, and to be one of 
              the most influential companies in delivering high-quality, intelligent content across all media.
            </p>
          </div>
          <div className="bg-gray-50 p-8 rounded-2xl">
            <h3 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
              <Award className="w-8 h-8 text-red-600 mr-3" />
              Our Mission
            </h3>
            <p className="text-gray-600 leading-relaxed">
              We strive to deliver high-quality content. As pioneers, we have contributed to the success 
              of the largest companies by setting measurable, achievable, and realistic marketing goals. 
              That's why we're the best.
            </p>
          </div>
        </div>

        {/* What We Do Section */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">What We Do</h3>
            <p className="text-xl text-gray-600">We're not just an agency, we're a trusted partner</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <div 
                key={service.name}
                className="bg-white border border-gray-200 p-6 rounded-xl hover:shadow-lg hover:border-red-200 transition-all duration-300 group"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mr-4 group-hover:bg-red-600 transition-colors duration-300">
                    <service.icon className="w-6 h-6 text-red-600 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h4 className="font-semibold text-gray-900 group-hover:text-red-600 transition-colors duration-300">
                    {service.name}
                  </h4>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Innovation Department */}
        <div className="bg-gradient-to-br from-red-50 to-gray-50 p-8 rounded-2xl">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-red-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Brain className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">AI and Innovation Department</h3>
            <p className="text-lg text-gray-600 mb-4">قسم الذكاء الاصطناعي والابتكار</p>
          </div>
          <p className="text-gray-600 leading-relaxed text-center max-w-4xl mx-auto">
            الهدف من القسم الذي يتمحور حول استخدام الذكاء الاصطناعي لتطوير حلول عملية ومبتكرة تغطي مجالات متعددة، 
            مع التركيز على قدرة القسم على الابتكار وتطبيق الذكاء الاصطناعي بشكل فعّال ومستدام داخل الشركة.
          </p>
        </div>
      </div>
    </section>
  );
}