import { Facebook, Instagram, Twitter, Youtube, Linkedin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-black text-white py-16 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-0 right-0 opacity-10 pointer-events-none">
        <img 
          src="/Twinhub Logo_Artboard 19.png"
          alt="Hub decorative"
          className="h-32 w-auto"
        />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <img 
              src="/Twinhub Logo_Artboard 14-2_Artboard 14.png" 
              alt="Twinhub Logo" 
              className="h-12 w-auto mb-6"
            />
            <p className="text-gray-300 leading-relaxed mb-6 max-w-md">
              TwinHub Agency keeps pace with the latest developments in advertising and AI, 
              offering creative design and implementation with speed, quality, and competitive prices.
            </p>
            
            {/* Social Media */}
            <div className="flex space-x-4">
              {[
                { icon: Instagram, href: '#', label: 'Instagram' },
                { icon: Facebook, href: '#', label: 'Facebook' },
                { icon: Twitter, href: '#', label: 'Twitter' },
                { icon: Youtube, href: '#', label: 'YouTube' },
                { icon: Linkedin, href: '#', label: 'LinkedIn' }
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="w-12 h-12 bg-gray-800 rounded-xl flex items-center justify-center hover:bg-red-600 transition-colors duration-300 group"
                >
                  <Icon className="w-5 h-5 text-gray-300 group-hover:text-white" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {['Home', 'Services', 'Portfolio', 'About', 'Contact'].map((link) => (
                <li key={link}>
                  <button className="text-gray-300 hover:text-red-400 transition-colors duration-300">
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-bold mb-6">Services</h3>
            <ul className="space-y-3">
              {[
                'AI Center',
                'Video Production',
                'Photography Production',
                'Branding & Design',
                'Exhibition & Events',
                'Copyright & Music'
              ].map((service) => (
                <li key={service}>
                  <button className="text-gray-300 hover:text-red-400 transition-colors duration-300">
                    {service}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Newsletter Signup */}
        <div className="border-t border-gray-800 pt-8 mb-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h3 className="text-lg font-bold mb-2">Stay Updated</h3>
              <p className="text-gray-300">Get the latest news and creative insights delivered to your inbox.</p>
            </div>
            <div className="flex w-full md:w-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 md:w-64 px-4 py-3 bg-gray-800 border border-gray-700 rounded-l-xl focus:ring-2 focus:ring-red-500 focus:border-transparent text-white placeholder-gray-400"
              />
              <button className="px-6 py-3 bg-red-600 text-white rounded-r-xl hover:bg-red-700 transition-colors duration-300 font-semibold">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between">
          <div className="text-gray-400 text-sm mb-4 md:mb-0">
            © 2024 TwinHub Media & AI Center. All rights reserved.
          </div>
          <div className="flex space-x-6 text-sm">
            <button className="text-gray-400 hover:text-white transition-colors duration-300">
              Privacy Policy
            </button>
            <button className="text-gray-400 hover:text-white transition-colors duration-300">
              Terms of Service
            </button>
            <button className="text-gray-400 hover:text-white transition-colors duration-300">
              Cookie Policy
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}